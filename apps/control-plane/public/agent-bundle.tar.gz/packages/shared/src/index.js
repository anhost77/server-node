"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExampleSchema = void 0;
const zod_1 = require("zod");
exports.ExampleSchema = zod_1.z.object({
    foo: zod_1.z.string()
});
//# sourceMappingURL=index.js.map